<?php

return [
    'name' => 'AreaModule'
];
