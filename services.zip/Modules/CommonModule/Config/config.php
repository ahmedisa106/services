<?php

return [
    'name' => 'CommonModule'
];
