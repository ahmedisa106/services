@extends('commonmodule::layouts.master')

@section('content')

@endsection
