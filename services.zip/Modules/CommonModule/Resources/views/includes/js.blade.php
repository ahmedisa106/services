<!-- BEGIN VENDOR JS-->
<script src="{{aurl()}}/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->


<script src="{{aurl()}}/app-assets/vendors/js/timeline/horizontal-timeline.js" type="text/javascript"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN MODERN JS-->
<script src="{{aurl()}}/app-assets/js/core/app-menu.js" type="text/javascript"></script>
<script src="{{aurl()}}/app-assets/js/core/app.js" type="text/javascript"></script>
<script src="{{aurl()}}/app-assets/js/scripts/customizer.js" type="text/javascript"></script>
<!-- END MODERN JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="{{aurl()}}/app-assets/js/scripts/pages/dashboard-ecommerce.js" type="text/javascript"></script>
<!-- END PAGE LEVEL JS-->
<script src="{{asset('assets')}}/custom/js/notify.min.js" type="text/javascript"></script>
<script src="{{asset('assets')}}/custom/js/progress.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/vendors/js/forms/icheck/icheck.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/js/scripts/forms/checkbox-radio.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/vendors/js/extensions/toastr.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/js/scripts/extensions/toastr.js" type="text/javascript"></script>

<script src="{{aurl('')}}/app-assets/vendors/js/extensions/jquery.toolbar.min.js" type="text/javascript"></script>

<script src="{{aurl('')}}/app-assets/js/scripts/extensions/toolbar.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/js/scripts/modal/components-modal.js" type="text/javascript"></script>

<script type="text/javascript" src="{{aurl('')}}/app-assets/vendors/js/ui/jquery.sticky.js"></script>
<script src="{{aurl('')}}/app-assets/vendors/js/extensions/datedropper.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/vendors/js/extensions/timedropper.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/js/scripts/extensions/date-time-dropper.js" type="text/javascript"></script>


<script src="{{aurl('')}}/app-assets/vendors/js/forms/toggle/bootstrap-switch.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/vendors/js/forms/toggle/bootstrap-checkbox.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
<script src="{{aurl('')}}/app-assets/js/scripts/forms/switch.js" type="text/javascript"></script>

<script src="{{aurl('assets/js/main.js')}}"></script>
<script>
    /* to display of right click */
    // $(document).ready(function (e) {
    //     $(document).bind("contextmenu", function (e) {
    //         return false;
    //     });
    //     $(document).keydown(function (e) {
    //         if (e.which === 123) {
    //
    //             return false;
    //
    //         }
    //
    //     });
    // });
    /*end display of*/
</script>
@stack('js')
