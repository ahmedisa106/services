<?php

namespace Modules\ConfigModule\Entities;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $guarded = [];
}
