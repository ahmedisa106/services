<script src="{{asset('assets/front/js/jquery-3.4.1.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery-ui.js')}}"></script>
<script src="{{asset('assets/front/js/popper.min.js')}}"></script>
<script src="{{asset('assets/front/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/front/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery.fancybox.min.js')}}"></script>
<script src="{{asset('assets/front/js/animated-headline.js')}}"></script>
<script src="{{asset('assets/front/js/chosen.min.js')}}"></script>
<script src="{{asset('assets/front/js/moment.min.js')}}"></script>
<script src="{{asset('assets/front/js/datedropper.min.js')}}"></script>
<script src="{{asset('assets/front/js/waypoints.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery.counterup.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery-rating.js')}}"></script>
<script src="{{asset('assets/front/js/tilt.jquery.min.js')}}"></script>
<script src="{{asset('assets/front/js/jquery-supperslides.min.js')}}"></script>
<script src="{{asset('assets/front/js/superslider-script.js')}}"></script>
<script src="{{asset('assets/front/js/jquery.lazy.min.js')}}"></script>
<script src="{{asset('assets/front/js/main-rtl.js')}}"></script>
<script src="{{asset('assets/front/main/main.js')}}"></script>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAYzby4yYDVaXPmtu4jZAGR258K6IYwjIY&libraries"></script>
<script src="{{asset('assets/front')}}/js/gmap-script.js"></script>
<script src="{{asset('assets/front')}}/js/jquery.MultiFile.min.js"></script>
<script src="{{asset('assets/front')}}/js/copy-text-script.js"></script>

