<?php

return [
    'name' => 'StoresModule'
];
