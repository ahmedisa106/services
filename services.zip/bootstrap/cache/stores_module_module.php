<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\StoresModule\\Providers\\StoresModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\StoresModule\\Providers\\StoresModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);