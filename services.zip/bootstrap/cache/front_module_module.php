<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FrontModule\\Providers\\FrontModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FrontModule\\Providers\\FrontModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);